@echo off
:: Run ZOrvixa.reworked NEW SHIT.exe in the same folder
start "" "%~dp0ZOrvixa.reworked NEW SHIT.exe"

:: Run MemoryOptimizer.ps1 in the same folder
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0MemoryOptimizer.ps1"