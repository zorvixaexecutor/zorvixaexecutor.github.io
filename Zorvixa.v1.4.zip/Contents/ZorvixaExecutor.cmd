@echo off
:: ----------------------------------------
:: Elevate batch file to run as administrator
:: ----------------------------------------
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrative privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: ----------------------------------------
:: Running commands as admin
:: ----------------------------------------
echo DO NOT CLOSE THIS WINDOW CLOSE THE EXECUTOR INSTEAD

echo Running EXE as admin...
start "" "%~dp0ZOrvixa.reworked NEW SHIT.exe"

echo Running PowerShell optimizer as admin...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0MemoryOptimizer.ps1"

echo All tasks completed.