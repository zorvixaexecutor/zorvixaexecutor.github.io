# Self-elevate if not running as admin
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "Restarting script as Administrator..."
    Start-Process -FilePath "powershell.exe" -ArgumentList "-ExecutionPolicy Bypass -File `"$($MyInvocation.MyCommand.Path)`"" -Verb RunAs
    exit
}

# Get the folder where this script is located
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Full path to the main executable
$exe = Join-Path $ScriptDir "ZOrvixa.reworked NEW SHIT.exe"

# Full path to the Bin folder
$bin = Join-Path $ScriptDir "Bin"

# Check if the EXE exists before starting
if (-Not (Test-Path $exe)) {
    Write-Host "ERROR: Cannot find executable at $exe"
    exit
}

# Unblock the EXE in case it was downloaded and blocked by Windows
try {
    Unblock-File -Path $exe
    Write-Host "Unblocked: $exe"
} catch {
    Write-Host "Failed to unblock: $exe (may not be blocked)"
}

# Start the main executable
$process = Start-Process -FilePath $exe -PassThru
Write-Host "Started process: $($process.Id)"

# Wait until the process exits
while ($true) {
    Start-Sleep -Seconds 2
    $running = Get-Process -Id $process.Id -ErrorAction SilentlyContinue

    if (-not $running) {
        Write-Host "Main process stopped. Cleaning Bin folder..."

        # Get all EXEs inside Bin
        $binFiles = Get-ChildItem -Path $bin -Filter *.exe -File -ErrorAction SilentlyContinue

        foreach ($file in $binFiles) {
            $name = [System.IO.Path]::GetFileNameWithoutExtension($file.Name)

            # Kill running processes matching the exe name
            Get-Process -Name $name -ErrorAction SilentlyContinue | ForEach-Object {
                Write-Host "Stopping process: $($_.Name) (ID: $($_.Id))"
                Stop-Process -Id $_.Id -Force
            }

            # Delete the exe file
            try {
                # Unblock before deleting to avoid permission issues
                Unblock-File -Path $file.FullName -ErrorAction SilentlyContinue
                Remove-Item $file.FullName -Force
                Write-Host "Deleted: $($file.Name)"
            } catch {
                Write-Host "Failed to delete: $($file.Name)"
            }
        }

        break
    }
}

Write-Host "Cleanup complete."