$exeName = "ZOrvixa.reworked NEW SHIT"  # main exe (no .exe)
$binPath = ".\Bin"

Write-Host "Waiting for process to start..."

# Wait until the process starts
while (-not (Get-Process -Name $exeName -ErrorAction SilentlyContinue)) {
    Start-Sleep -Seconds 1
}

Write-Host "Process started. Monitoring..."

# Wait until the process stops
while (Get-Process -Name $exeName -ErrorAction SilentlyContinue) {
    Start-Sleep -Seconds 1
}

Write-Host "Process stopped."

# Check if Bin exists
if (Test-Path $binPath) {
    Write-Host "Scanning for active EXEs in Bin..."

    # Get all running processes with a path inside ./Bin
    $binFullPath = (Resolve-Path $binPath).Path

    $runningInBin = Get-Process | Where-Object {
        $_.Path -and ($_.Path.StartsWith($binFullPath))
    }

    if ($runningInBin) {
        Write-Host "Found active processes in Bin. Stopping them..."

        foreach ($proc in $runningInBin) {
            try {
                Stop-Process -Id $proc.Id -Force
                Write-Host "Stopped: $($proc.ProcessName)"
            }
            catch {
                Write-Host "Failed to stop: $($proc.ProcessName)"
            }
        }
    }
    else {
        Write-Host "No active EXEs found in Bin."
    }

    Write-Host "Deleting Bin folder..."

    try {
        Remove-Item $binPath -Recurse -Force
        Write-Host "Bin folder deleted successfully."
    }
    catch {
        Write-Host "Failed to delete Bin folder: $_"
    }
}
else {
    Write-Host "Bin folder does not exist."
}

Write-Host "Script finished."